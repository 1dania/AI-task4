# turtlesim_control

This package demonstrates how to control the turtlesim node in ROS2 using a Python script.

## Usage

1. Run turtlesim node:
```bash
ros2 run turtlesim turtlesim_node
```

2. Run the control node:
```bash
ros2 run turtlesim_control turtle_move
```